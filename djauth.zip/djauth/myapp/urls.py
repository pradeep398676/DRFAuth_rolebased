from django.urls import path
from myapp.views import StudentView, TeacherView, PublicView

urlpatterns = [
    path('teacher/', TeacherView.as_view(), name='teacher-view'),
    path('student/', StudentView.as_view(), name='student-view'),
    path('public/', PublicView.as_view(), name='public-view'),
]
