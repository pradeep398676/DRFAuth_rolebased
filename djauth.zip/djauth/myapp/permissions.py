from rest_framework.permissions import BasePermission


class IsStudentUser(BasePermission):
   

    def has_permission(self, request, view):
        return request.user.role == 'Student'


class IsTeacherUser(BasePermission):
  

    def has_permission(self, request, view):
        return request.user.role == 'Teacher'
