from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from myapp.permissions import IsStudentUser, IsTeacherUser


class TeacherView(APIView):
    permission_classes = [IsAuthenticated, IsTeacherUser]

    def get(self, request):
        return Response({"message": "Hello Teacher!"})


class StudentView(APIView):
    permission_classes = [IsAuthenticated, IsStudentUser]

    def get(self, request):
        return Response({"message": "Hello Student!"})


class PublicView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        return Response({"message": "Hello Public!"})
