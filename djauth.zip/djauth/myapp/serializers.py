from rest_framework.serializers import ModelSerializer
from myapp.models import MyUser


# it is optional

# class MyUserSerializer(ModelSerializer):
#     class Meta:
#         model = MyUser
#         fields = ['username','password']